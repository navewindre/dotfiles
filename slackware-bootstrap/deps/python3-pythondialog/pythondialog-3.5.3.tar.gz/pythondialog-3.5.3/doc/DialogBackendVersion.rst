.. currentmodule:: dialog

The :class:`!DialogBackendVersion` class
========================================

.. autoclass:: DialogBackendVersion
   :show-inheritance:
   :members:
   :undoc-members:

