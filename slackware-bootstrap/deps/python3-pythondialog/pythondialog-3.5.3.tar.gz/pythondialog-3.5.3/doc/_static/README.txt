This file ensures the containing directory will be part of Git checkouts and
release tarballs.
